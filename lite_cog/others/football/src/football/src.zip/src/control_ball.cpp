
#include<iostream>
#include<algorithm>
#include<fstream>
#include<chrono>

#include <ros/ros.h>
#include <std_msgs/String.h>
#include <geometry_msgs/PoseStamped.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <pcl/common/projection_matrix.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>

#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <tf_conversions/tf_eigen.h>
#include "Eigen/Core"
#include "Eigen/Geometry"
//#include <track_ball/RotatedRectStamped.h>
#include <detect_ball/circle.h>
#include<geometry_msgs/Twist.h>

using namespace std;
using namespace cv;

ros::Subscriber Control_sub;
ros::Publisher Control_pub;
//接收的球的中心坐标和半径
float center_x = 0;
float center_y = 0;
float radius = 0;
//接收的图像大小
float WIDTH = 640;
float HEIGHT = 480;
//最大线速度和角速度
float maxr = 4;
float maxv = 2;
//线速度和角速度的控制差
float delta_r = 0;
float delta_v = 0;
//半径的阈值
float threshold_r = 100;
//实际发送的速度值
float vel_r = 0;
float vel_v = 0;
//读取球的位置和半径，发送速度
void control_ball_recall(const detect_ball::circle msg)
{
    center_x = msg.center_x;
    center_y = msg.center_y;
    radius = msg.radius;

    delta_r = (WIDTH/2 - center_x)/WIDTH;
    vel_r = maxr * delta_r;
    delta_v = (threshold_r - radius)/HEIGHT;
    vel_v = maxv * delta_v;

    ROS_INFO("r : %f, v: %f", vel_r, vel_v);
    geometry_msgs::Twist vel_msg;
    vel_msg.linear.x = vel_v;
    vel_msg.angular.z = vel_r;
    Control_pub.publish(vel_msg);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "control_ball");
    ros::start();
    ros::NodeHandle nh;

    Control_sub = nh.subscribe<detect_ball::circle>("/ball_track_box", 10, control_ball_recall);
	Control_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    ros::spin();
    
    return 0;
}


