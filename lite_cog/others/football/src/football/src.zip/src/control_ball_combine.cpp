
#include<iostream>
#include<algorithm>
#include<fstream>
#include<chrono>

#include <ros/ros.h>
#include <std_msgs/String.h>
#include <geometry_msgs/PoseStamped.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <pcl/common/projection_matrix.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>

#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <tf_conversions/tf_eigen.h>
#include "Eigen/Core"
#include "Eigen/Geometry"
//#include <track_ball/RotatedRectStamped.h>
#include <detect_ball/circle.h>
#include<geometry_msgs/Twist.h>

using namespace std;
using namespace cv;

ros::Subscriber Control_sub;
ros::Publisher Control_pub;
ros::Subscriber Control_sub_real_sense;
//球的位置和半径 usb和real——sense
float center_x = 0;
float center_y = 0;
float radius = 0;

float center_x_real_sense = 0;
float center_y_real_sense = 0;
float radius_real_sense = 0;
//图像大小
float WIDTH = 640;
float HEIGHT = 480;

float WIDTH_REAL = 424;
float HEIGHT_REAL = 240;
//最大速度
float maxr = 4;
float maxv = 2;
//速度差
float delta_r = 0;
float delta_v = 0;
float threshold_r = 100;

float delta_r_real_sense = 0;
float delta_v_real_sense = 0;
float threshold_r_real_sense = 60;
//实际发送速度
float vel_r = 0;
float vel_v = 0;

float vel_r_real_sense = 0;
float vel_v_real_sense = 0;

float r = 0;
float v= 0;
//定点停止
int flag = 1;

void control_ball_recall(const detect_ball::circle msg)
{
    center_x = msg.center_x;
    center_y = msg.center_y;
    radius = msg.radius;

    delta_r = (WIDTH/2 - center_x)/WIDTH;
    vel_r = maxr * delta_r;
    delta_v = (threshold_r - radius)/HEIGHT;
    vel_v = maxv * delta_v;

    // ROS_INFO("vel_r : %f, vel_v: %f", vel_r, vel_v);
    // geometry_msgs::Twist vel_msg;
    // vel_msg.linear.x = vel_v;
    // vel_msg.angular.z = vel_r;
    // Control_pub.publish(vel_msg);
}

void control_ball_recall_real_sense(const detect_ball::circle msg)
{
    center_x_real_sense = msg.center_x;
    center_y_real_sense = msg.center_y;
    radius_real_sense = msg.radius;
    ROS_INFO("radius : %f", radius_real_sense);

    delta_r_real_sense = (WIDTH_REAL/2 - center_x_real_sense)/WIDTH_REAL/2;
    vel_r_real_sense = maxr * delta_r_real_sense;
    delta_v_real_sense = (threshold_r_real_sense - radius_real_sense)/HEIGHT_REAL/2;
    vel_v_real_sense = maxv * delta_v_real_sense;
    // ROS_INFO("vel_r_real_sense : %f, v: %f", vel_r_real_sense, vel_v_real_sense);
    //球进入到real_sense视野之后，用real_sense相机控制
    if(radius_real_sense > 25){
        r = vel_r_real_sense;
        v = vel_v_real_sense;
        ROS_INFO("r1 : %f, v: %f", r,  v); 
        if(radius_real_sense > 50) flag = 0;      
    }
    else{
        r = vel_r;
        v = vel_v;
        ROS_INFO("r2 : %f, v: %f", r,  v);     
    }
    geometry_msgs::Twist vel_msg;
    vel_msg.linear.x = v * flag;
    vel_msg.angular.z = r * flag;
    Control_pub.publish(vel_msg);
    // ROS_INFO("r : %f, v: %f", r,  v);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "control_ball");
    ros::start();
    ros::NodeHandle nh;

    Control_sub = nh.subscribe<detect_ball::circle>("/ball_track_box", 10, control_ball_recall);
    Control_sub_real_sense = nh.subscribe<detect_ball::circle>("/ball_track_box_real_sense", 10, control_ball_recall_real_sense);
	Control_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    ros::spin();
    
    return 0;
}


