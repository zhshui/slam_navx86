
#include<iostream>
#include<algorithm>
#include<fstream>
#include<chrono>
#include<math.h>

#include <ros/ros.h>
#include <std_msgs/String.h>
#include <geometry_msgs/PoseStamped.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <pcl/common/projection_matrix.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>

#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <tf_conversions/tf_eigen.h>
#include "Eigen/Core"
#include "Eigen/Geometry"
//#include <track_ball/RotatedRectStamped.h>
#include <detect_ball/circle.h>


using namespace std;
using namespace cv;

static const std::string OPENCV_WINDOW = "Image window";
ros::Subscriber Subimage;
ros::Publisher Pubtrack_box;

float WIDTH = 424;
float HEIGHT = 240;
float threshold_r = 100;

float center_last_x = WIDTH/2;
float center_last_y = HEIGHT/2;
float radius_last = threshold_r;

void image_recall(const sensor_msgs::ImageConstPtr &msgRGB)
{
    // Copy the ros image message to cv::Mat.
    cv_bridge::CvImageConstPtr cv_ptrRGB;
    try
    {
        cv_ptrRGB = cv_bridge::toCvCopy(msgRGB, "bgr8");
    }
    catch (cv_bridge::Exception &e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }

    cv::Mat rgb_img = cv_ptrRGB->image;

    // ROS_INFO("a : %d", rgb_img.cols);
    cv::Mat hsv_img;
    cvtColor(rgb_img, hsv_img, CV_BGR2HSV);//rgb->hsv图像

	vector<cv::Mat> hsvChannels;
    cv::Mat  b1;
    cv::Mat  b2;
    cv::Mat  bi;
	split(hsv_img, hsvChannels);//分解通道彩色显示

    b1 = (hsvChannels[0] > 0) & (hsvChannels[0] < 10) & (hsvChannels[1] > 50) & (hsvChannels[1] < 255) & (hsvChannels[2]>100) & (hsvChannels[2]<255);//颜色控制
    b2 = (hsvChannels[0] > 156) & (hsvChannels[0] < 180) & (hsvChannels[1] > 50) & (hsvChannels[1] < 255) & (hsvChannels[2]>100) & (hsvChannels[2]<255) ;//颜色控制
    bi = b1 | b2;
    // imshow("bi", bi);

    cv::Mat gauss;
    cv::GaussianBlur(bi, gauss, cv::Size(5, 5),2 ,2);

    cv::Mat element;
    element = getStructuringElement(MORPH_RECT, Size(5,5));
    cv::Mat eroded;
    cv::erode(gauss, eroded, element);
    cv::Mat dilated;
    cv::dilate(eroded, dilated, element);
    // cv::imshow("dilated", dilated);

    vector<vector<Point>> contours;
    vector<Vec4i> hierarchy;
    vector<Point> max_c;
    findContours(dilated, contours, hierarchy, RETR_LIST, CHAIN_APPROX_SIMPLE, Point());//寻找物体轮廓
    int maxarea = 0,area = 0;
    for(int i=0;i<int(contours.size());i++){
        area = contourArea(contours[i]);//计算轮廓的面积
        if(area > maxarea){
            maxarea = area;
            max_c = contours[i];
        }
    }
    if(maxarea>200){
        Point2f center;
        float radius;

        float s = cv::contourArea(max_c);
        float c = cv::arcLength(max_c, true);
        float afa = 4 * M_PI * s / (c * c);
        afa = abs(afa - 1);
        // ROS_INFO("afa : %f", afa);
        if(afa < 0.75){
            detect_ball::circle  ball_circle;
            minEnclosingCircle(max_c, center,radius);//寻找包裹轮廓的最小圆
            ball_circle.center_x = center.x;
            ball_circle.center_y = center.y;
            // ROS_INFO("center.x : %f", center.x);
            ball_circle.radius = radius;
            center_last_x = center.x;
            center_last_y = center.y;
            radius_last = radius;
            Scalar color = Scalar(255, 0, 0);
            circle(rgb_img, center, radius, color, 2);
            circle(rgb_img, center, 2, color, -1);  
            Pubtrack_box.publish(ball_circle);  
        }
    }
    else{
        // detect_ball::circle  ball_circle;
        // ball_circle.center_x = center_last_x;
        // ball_circle.center_y = center_last_y;
        // ball_circle.radius = radius_last;
        // Pubtrack_box.publish(ball_circle);  
        detect_ball::circle  ball_circle;
        ball_circle.center_x = WIDTH/2;
        ball_circle.radius = 0;
        Pubtrack_box.publish(ball_circle);  
    }

    // cv::namedWindow(OPENCV_WINDOW, 0);
    // cv::resizeWindow(OPENCV_WINDOW, 960, 540);
    cv::imshow(OPENCV_WINDOW, rgb_img);
    cv::waitKey(1);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "detect_ball_real_sense");
    ros::start();
    ros::NodeHandle nh;

    Subimage = nh.subscribe<sensor_msgs::Image>("/camera/color/image_raw", 10, image_recall);
    // Subimage = nh.subscribe<sensor_msgs::Image>("camera/image", 10, image_recall);
	Pubtrack_box = nh.advertise<detect_ball::circle>("/ball_track_box_real_sense", 10);
    ros::spin();
    
    return 0;
}


